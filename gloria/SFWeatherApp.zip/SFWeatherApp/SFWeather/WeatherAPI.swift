//
//  WeatherAPI.swift
//  SFWeather
//
//  Created by Gloria Chan on 11/30/17.
//  Copyright © 2017 Daniel. All rights reserved.
//

import Foundation

struct WeatherAPI {
    // https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(lon)&appid=e84361abfff7e3a663da48cdaf23ea18
    
    struct Constants {
        static let ApiKey = "e84361abfff7e3a663da48cdaf23ea18"
        static let BaseURL = "https://api.openweathermap.org/data/2.5/"
    }
    struct Resources {
        
    }
    struct Keys {
        
    }
}
